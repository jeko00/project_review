<?php
/**
 * @package		com_hshrndprojects
 * @copyright   Copyright (c)2016 Jens H. Kowal / me.com
 * @license		GNU General Public License version 2 or later
 */

namespace HSH\HSHRnDReview\Site\Controller;

defined('_JEXEC') or die();

use FOF30\Controller\Controller;

class ThankYou extends Controller
{

}