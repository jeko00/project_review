<?php
/**
 * @package		hshrndreview
 * @copyright	Copyright (c)2016 jk
 * @license		GNU General Public License version 2 or later
 */

namespace HSH\HSHRnDReview\Site\Controller;

use HSH\HSHRnDReview\Site\Model\Controllers;
use FOF30\Controller\DataController;

defined('_JEXEC') or die();

class Collaborator extends DataController
{
}